export interface BodyMeasurement {
  id: string;
  name: string;
  category: 'Upper Body & Torso' | 'Arms & Hands' | 'Waist, Hips & Seat' | 'Lower Body & Legs' | 'Head & Neck';
  valueCm: number;
  valueIn: number;
  description: string;
  landmark: string;
}

export interface MeasureResponse {
  measurements: BodyMeasurement[];
  detectionNotes?: string;
  heightCm: number;
  heightIn: number;
  timestamp: string;
}

export const REQUIRED_38_DIMENSIONS: {
  id: string;
  name: string;
  category: 'Upper Body & Torso' | 'Arms & Hands' | 'Waist, Hips & Seat' | 'Lower Body & Legs' | 'Head & Neck';
  landmark: string;
  defaultRatioToHeight: number; // typical ratio of height for circumference or length
  isCircumference: boolean;
}[] = [
  // Head & Neck
  {
    id: 'head-circ',
    name: 'Head circumference',
    category: 'Head & Neck',
    landmark: 'Around head above eyebrows and ears at widest part of occiput',
    defaultRatioToHeight: 0.33,
    isCircumference: true,
  },
  {
    id: 'neck-circ',
    name: 'Neck circumference',
    category: 'Head & Neck',
    landmark: 'Circumference at neck base directly above clavicles',
    defaultRatioToHeight: 0.22,
    isCircumference: true,
  },

  // Upper Body & Torso
  {
    id: 'chest-circ',
    name: 'Chest circumference',
    category: 'Upper Body & Torso',
    landmark: 'Horizontal circumference around fullest part of chest across shoulder blades',
    defaultRatioToHeight: 0.56,
    isCircumference: true,
  },
  {
    id: 'high-bust',
    name: 'High bust',
    category: 'Upper Body & Torso',
    landmark: 'Circumference around torso directly under armpits, above bust mound',
    defaultRatioToHeight: 0.52,
    isCircumference: true,
  },
  {
    id: 'high-bust-front',
    name: 'High bust front',
    category: 'Upper Body & Torso',
    landmark: 'Front arc from side seam to side seam across upper chest above bust',
    defaultRatioToHeight: 0.24,
    isCircumference: false,
  },
  {
    id: 'bust-front',
    name: 'Bust front',
    category: 'Upper Body & Torso',
    landmark: 'Front arc between side seams across apex/fullest point of bust',
    defaultRatioToHeight: 0.27,
    isCircumference: false,
  },
  {
    id: 'bust-point-to-underbust',
    name: 'Bust point to underbust',
    category: 'Upper Body & Torso',
    landmark: 'Vertical distance from bust apex down along curve to inframammary fold',
    defaultRatioToHeight: 0.052,
    isCircumference: false,
  },
  {
    id: 'bust-span',
    name: 'Bust span',
    category: 'Upper Body & Torso',
    landmark: 'Horizontal distance between left and right bust points (apex to apex)',
    defaultRatioToHeight: 0.11,
    isCircumference: false,
  },
  {
    id: 'underbust',
    name: 'Underbust',
    category: 'Upper Body & Torso',
    landmark: 'Horizontal circumference directly beneath breasts along inframammary crease',
    defaultRatioToHeight: 0.44,
    isCircumference: true,
  },
  {
    id: 'hps-to-bust',
    name: 'HPS to bust',
    category: 'Upper Body & Torso',
    landmark: 'High Point Shoulder (neck-shoulder intersect) down to bust point',
    defaultRatioToHeight: 0.155,
    isCircumference: false,
  },
  {
    id: 'hps-to-waist-front',
    name: 'HPS to waist front',
    category: 'Upper Body & Torso',
    landmark: 'High Point Shoulder over bust apex down to front natural waistline',
    defaultRatioToHeight: 0.25,
    isCircumference: false,
  },
  {
    id: 'hps-to-waist-back',
    name: 'HPS to waist back',
    category: 'Upper Body & Torso',
    landmark: 'High Point Shoulder down across back curvature to back natural waistline',
    defaultRatioToHeight: 0.245,
    isCircumference: false,
  },
  {
    id: 'shoulder-slope',
    name: 'Shoulder slope',
    category: 'Upper Body & Torso',
    landmark: 'Angular or vertical drop from neck-shoulder intersection to outer acromion',
    defaultRatioToHeight: 0.035,
    isCircumference: false,
  },
  {
    id: 'shoulder-to-shoulder',
    name: 'Shoulder to shoulder',
    category: 'Upper Body & Torso',
    landmark: 'Horizontal cross-back distance between left and right acromion bone tips',
    defaultRatioToHeight: 0.24,
    isCircumference: false,
  },
  {
    id: 'waist-to-armpit',
    name: 'Waist to armpit',
    category: 'Upper Body & Torso',
    landmark: 'Vertical distance along side seam from natural waist up to base of armpit',
    defaultRatioToHeight: 0.12,
    isCircumference: false,
  },
  {
    id: 'waist-to-underbust',
    name: 'Waist to underbust',
    category: 'Upper Body & Torso',
    landmark: 'Vertical distance from front natural waistline up to underbust crease',
    defaultRatioToHeight: 0.055,
    isCircumference: false,
  },

  // Arms & Hands
  {
    id: 'biceps-circ',
    name: 'Biceps circumference',
    category: 'Arms & Hands',
    landmark: 'Circumference at fullest horizontal point of upper arm between shoulder and elbow',
    defaultRatioToHeight: 0.17,
    isCircumference: true,
  },
  {
    id: 'shoulder-to-elbow',
    name: 'Shoulder to elbow',
    category: 'Arms & Hands',
    landmark: 'Distance from shoulder acromion point down along arm to tip of olecranon (elbow)',
    defaultRatioToHeight: 0.195,
    isCircumference: false,
  },
  {
    id: 'shoulder-to-wrist',
    name: 'Shoulder to wrist',
    category: 'Arms & Hands',
    landmark: 'Total arm length from shoulder tip over elbow to wrist styloid bone',
    defaultRatioToHeight: 0.355,
    isCircumference: false,
  },
  {
    id: 'wrist-circ',
    name: 'Wrist circumference',
    category: 'Arms & Hands',
    landmark: 'Circumference taken over distal styloid processes of radius and ulna',
    defaultRatioToHeight: 0.095,
    isCircumference: true,
  },

  // Waist, Hips & Seat
  {
    id: 'waist-circ',
    name: 'Waist circumference',
    category: 'Waist, Hips & Seat',
    landmark: 'Horizontal circumference around narrowest torso level (natural waist)',
    defaultRatioToHeight: 0.45,
    isCircumference: true,
  },
  {
    id: 'waist-back',
    name: 'Waist back',
    category: 'Waist, Hips & Seat',
    landmark: 'Back arc from side seam to side seam across back natural waistline',
    defaultRatioToHeight: 0.22,
    isCircumference: false,
  },
  {
    id: 'waist-to-hips',
    name: 'Waist to hips',
    category: 'Waist, Hips & Seat',
    landmark: 'Vertical distance from natural waistline down along side seam to high hip level',
    defaultRatioToHeight: 0.065,
    isCircumference: false,
  },
  {
    id: 'waist-to-seat',
    name: 'Waist to seat',
    category: 'Waist, Hips & Seat',
    landmark: 'Vertical distance from natural waistline down to level of fullest gluteal protrusion',
    defaultRatioToHeight: 0.125,
    isCircumference: false,
  },
  {
    id: 'hips-circ',
    name: 'Hips circumference',
    category: 'Waist, Hips & Seat',
    landmark: 'Circumference around pelvic rim (high hips) across iliac crests',
    defaultRatioToHeight: 0.54,
    isCircumference: true,
  },
  {
    id: 'seat-circ',
    name: 'Seat circumference',
    category: 'Waist, Hips & Seat',
    landmark: 'Full horizontal circumference around maximum projection of buttocks/gluteals',
    defaultRatioToHeight: 0.58,
    isCircumference: true,
  },
  {
    id: 'seat-back',
    name: 'Seat back',
    category: 'Waist, Hips & Seat',
    landmark: 'Back contour arc between side seams across fullest point of seat',
    defaultRatioToHeight: 0.295,
    isCircumference: false,
  },

  // Lower Body & Legs
  {
    id: 'crotch-depth',
    name: 'Crotch depth',
    category: 'Lower Body & Legs',
    landmark: 'Vertical distance from waistline down to level of perineal crotch line',
    defaultRatioToHeight: 0.16,
    isCircumference: false,
  },
  {
    id: 'cross-seam',
    name: 'Cross seam',
    category: 'Lower Body & Legs',
    landmark: 'Total crotch curve from center front waist down through perineum to center back waist',
    defaultRatioToHeight: 0.40,
    isCircumference: false,
  },
  {
    id: 'cross-seam-front',
    name: 'Cross seam front',
    category: 'Lower Body & Legs',
    landmark: 'Front crotch curve length from front center waistline to center crotch point',
    defaultRatioToHeight: 0.165,
    isCircumference: false,
  },
  {
    id: 'inseam',
    name: 'Inseam',
    category: 'Lower Body & Legs',
    landmark: 'Inside leg length from perineum/crotch fork along inner leg down to floor/ankle',
    defaultRatioToHeight: 0.45,
    isCircumference: false,
  },
  {
    id: 'upper-leg-circ',
    name: 'Upper leg circumference',
    category: 'Lower Body & Legs',
    landmark: 'Circumference of thigh measured immediately below the gluteal fold',
    defaultRatioToHeight: 0.32,
    isCircumference: true,
  },
  {
    id: 'waist-to-upper-leg',
    name: 'Waist to upper leg',
    category: 'Lower Body & Legs',
    landmark: 'Vertical distance from natural waist down to upper thigh circumference level',
    defaultRatioToHeight: 0.17,
    isCircumference: false,
  },
  {
    id: 'knee-circ',
    name: 'Knee circumference',
    category: 'Lower Body & Legs',
    landmark: 'Circumference horizontally around center of patella with leg extended',
    defaultRatioToHeight: 0.21,
    isCircumference: true,
  },
  {
    id: 'waist-to-knee',
    name: 'Waist to knee',
    category: 'Lower Body & Legs',
    landmark: 'Vertical distance along side seam from natural waist down to mid-patella level',
    defaultRatioToHeight: 0.34,
    isCircumference: false,
  },
  {
    id: 'waist-to-floor',
    name: 'Waist to floor',
    category: 'Lower Body & Legs',
    landmark: 'Vertical side length from natural waist down to floor without shoes',
    defaultRatioToHeight: 0.60,
    isCircumference: false,
  },
  {
    id: 'ankle-circ',
    name: 'Ankle circumference',
    category: 'Lower Body & Legs',
    landmark: 'Circumference at narrowest point of lower leg directly above malleoli',
    defaultRatioToHeight: 0.13,
    isCircumference: true,
  },
  {
    id: 'heel-circ',
    name: 'Heel circumference',
    category: 'Lower Body & Legs',
    landmark: 'Diagonal circumference around back of calcaneus heel and front instep ankle crease',
    defaultRatioToHeight: 0.19,
    isCircumference: true,
  },
];
