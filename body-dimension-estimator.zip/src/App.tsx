/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import {
  Camera,
  RotateCcw,
  Upload,
  Sparkles,
  AlertCircle,
  FlipHorizontal,
  Clock,
} from 'lucide-react';
import { ProgrammaticOutput } from './components/ProgrammaticOutput.tsx';
import { BodyMeasurement, REQUIRED_38_DIMENSIONS } from './types/measurements.ts';

export default function App() {
  // Height input state
  const [heightValue, setHeightValue] = useState<number>(175);
  const [heightUnit, setHeightUnit] = useState<'cm' | 'in'>('cm');

  // Camera & Stream state
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  // Timer
  const [timerSeconds, setTimerSeconds] = useState<number>(3);
  const [countdown, setCountdown] = useState<number>(0);

  // Processing & Data state
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>(() => {
    // Provide initial baseline based on 175 cm so output is immediately previewable
    const h = 175;
    return REQUIRED_38_DIMENSIONS.map((spec) => {
      const cm = Number((h * spec.defaultRatioToHeight).toFixed(1));
      return {
        id: spec.id,
        name: spec.name,
        category: spec.category,
        valueCm: cm,
        valueIn: Number((cm / 2.54).toFixed(1)),
        description: spec.landmark,
        landmark: spec.landmark,
      };
    });
  });
  const [hasCalculated, setHasCalculated] = useState<boolean>(false);

  // Compute normalized height in cm
  const computedHeightCm = heightUnit === 'cm' ? heightValue : Math.round(heightValue * 2.54);
  const computedHeightIn = Number((computedHeightCm / 2.54).toFixed(1));

  // Initialize camera
  const startCamera = async (mode: 'user' | 'environment') => {
    try {
      setCameraError(null);
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Camera access unavailable:', err);
      setCameraError('Camera unavailable. You can upload a photo.');
    }
  };

  useEffect(() => {
    startCamera(facingMode);
    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [facingMode]);

  const toggleCamera = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  const handleCapture = () => {
    if (timerSeconds > 0) {
      setCountdown(timerSeconds);
      const interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            takeSnapshotAndProcess();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      takeSnapshotAndProcess();
    }
  };

  const takeSnapshotAndProcess = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedImage(dataUrl);
    processImage(dataUrl);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCapturedImage(dataUrl);
        processImage(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const processImage = async (dataUrl: string) => {
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/measure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          heightCm: computedHeightCm,
          imageBase64: dataUrl,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to determine dimensions.');
      }

      const data = await res.json();
      if (Array.isArray(data.measurements) && data.measurements.length > 0) {
        setMeasurements(data.measurements);
        setHasCalculated(true);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Error processing image.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    if (!stream) {
      startCamera(facingMode);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm">
              BD
            </div>
            <div>
              <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                Body Dimensions Extractor
              </h1>
              <p className="text-[11px] text-slate-400">
                Input height &rarr; Camera capture &rarr; 38 clothing dimensions for external programs
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`text-[11px] font-mono font-semibold px-2.5 py-1 rounded-md border ${
                hasCalculated
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {hasCalculated ? 'Live Calibrated' : 'Schema Baseline'}
            </span>
          </div>
        </div>
      </header>

      {/* Main Dual-Column Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Height Input & Camera (5 cols on lg) */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {/* 1. Height Input Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                1. Input Height
              </label>
              <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800 text-[11px]">
                <button
                  type="button"
                  onClick={() => {
                    if (heightUnit === 'in') {
                      setHeightUnit('cm');
                      setHeightValue(Math.round(heightValue * 2.54));
                    }
                  }}
                  className={`px-2 py-0.5 rounded font-bold transition-all ${
                    heightUnit === 'cm'
                      ? 'bg-amber-500 text-slate-950'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  cm
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (heightUnit === 'cm') {
                      setHeightUnit('in');
                      setHeightValue(Math.round(heightValue / 2.54));
                    }
                  }}
                  className={`px-2 py-0.5 rounded font-bold transition-all ${
                    heightUnit === 'in'
                      ? 'bg-amber-500 text-slate-950'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  in
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                min={heightUnit === 'cm' ? 100 : 40}
                max={heightUnit === 'cm' ? 250 : 100}
                value={heightValue}
                onChange={(e) => setHeightValue(Number(e.target.value))}
                className="w-full text-2xl font-mono font-bold bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
              <span className="text-sm font-mono text-slate-400 font-semibold px-2">
                {heightUnit}
              </span>
            </div>

            <div className="flex items-center justify-between mt-2 text-[11px] text-slate-400">
              <span>
                Equivalent:{' '}
                <strong className="text-slate-300">
                  {heightUnit === 'cm'
                    ? `${(heightValue / 2.54).toFixed(1)} in`
                    : `${Math.round(heightValue * 2.54)} cm`}
                </strong>
              </span>
              <span>Used to scale dimensions</span>
            </div>
          </div>

          {/* 2. Camera Viewfinder Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-sm flex flex-col flex-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                2. Camera Viewfinder
              </span>
              <div className="flex items-center gap-1.5 text-xs">
                {/* Timer select */}
                <div className="flex items-center bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800 text-[11px] text-slate-400">
                  <Clock className="w-3 h-3 mr-1" />
                  {[0, 3, 5].map((sec) => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => setTimerSeconds(sec)}
                      className={`px-1.5 py-0.5 rounded font-semibold ${
                        timerSeconds === sec ? 'text-amber-400' : 'hover:text-white'
                      }`}
                    >
                      {sec === 0 ? '0s' : `${sec}s`}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={toggleCamera}
                  title="Switch camera"
                  className="p-1.5 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white rounded border border-slate-800"
                >
                  <FlipHorizontal className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Video or Snapshot Area */}
            <div className="relative bg-black rounded-lg overflow-hidden border border-slate-800 aspect-[4/3] flex items-center justify-center">
              <canvas ref={canvasRef} className="hidden" />

              {capturedImage ? (
                <div className="relative w-full h-full">
                  <img
                    src={capturedImage}
                    alt="Captured snapshot"
                    className="w-full h-full object-contain"
                  />
                  {isProcessing && (
                    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center">
                      <Sparkles className="w-8 h-8 text-amber-400 animate-spin mb-2" />
                      <span className="text-xs font-bold text-white">
                        Extracting 38 Dimensions...
                      </span>
                      <span className="text-[11px] text-slate-400 mt-1">
                        Calibrating against {computedHeightCm} cm
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="relative w-full h-full flex items-center justify-center">
                  {cameraError ? (
                    <div className="p-4 text-center text-xs text-slate-400">
                      <AlertCircle className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                      <p className="mb-3">{cameraError}</p>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded text-xs cursor-pointer"
                      >
                        Upload Photo
                      </button>
                    </div>
                  ) : (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                      />

                      {/* Simple alignment overlay line */}
                      <div className="absolute inset-x-0 top-3 text-[10px] text-amber-400 font-mono text-center pointer-events-none drop-shadow">
                        ── Head Top ──
                      </div>
                      <div className="absolute inset-x-0 bottom-3 text-[10px] text-amber-400 font-mono text-center pointer-events-none drop-shadow">
                        ── Feet / Ground ──
                      </div>

                      {/* Countdown overlay */}
                      {countdown > 0 && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10">
                          <span className="text-6xl font-black text-amber-400 font-mono">
                            {countdown}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Hidden upload input */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Error message */}
            {errorMessage && (
              <div className="mt-2 p-2 bg-red-500/10 border border-red-500/30 text-red-300 rounded text-xs">
                {errorMessage}
              </div>
            )}

            {/* Action Buttons */}
            <div className="mt-3 flex items-center gap-2">
              {capturedImage ? (
                <>
                  <button
                    type="button"
                    onClick={handleRetake}
                    disabled={isProcessing}
                    className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Retake</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => processImage(capturedImage)}
                    disabled={isProcessing}
                    className="flex-1 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Recalculate</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer"
                    title="Upload full body image"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Upload</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCapture}
                    disabled={isProcessing || countdown > 0}
                    className="flex-1 py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-lg text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Camera className="w-4 h-4" />
                    <span>
                      {timerSeconds > 0
                        ? `Capture (${timerSeconds}s Timer)`
                        : 'Capture & Determine Dimensions'}
                    </span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Output Data for another program (7 cols on lg) */}
        <div className="lg:col-span-7 flex flex-col h-full min-h-[500px]">
          <ProgrammaticOutput
            measurements={measurements}
            heightCm={computedHeightCm}
            heightIn={computedHeightIn}
          />
        </div>
      </main>
    </div>
  );
}
