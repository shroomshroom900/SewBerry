import React, { useState, useEffect } from 'react';
import { Ruler, ArrowRight, CheckCircle2 } from 'lucide-react';

interface HeightInputStepProps {
  initialHeightCm: number;
  onHeightConfirmed: (heightCm: number) => void;
}

export const HeightInputStep: React.FC<HeightInputStepProps> = ({
  initialHeightCm,
  onHeightConfirmed,
}) => {
  const [unit, setUnit] = useState<'cm' | 'ft_in'>('cm');
  const [cmValue, setCmValue] = useState<number>(initialHeightCm || 172);

  // Imperial state
  const [feet, setFeet] = useState<number>(5);
  const [inches, setInches] = useState<number>(8);

  // Sync imperial when cm changes
  useEffect(() => {
    if (cmValue > 0) {
      const totalInches = cmValue / 2.54;
      const ft = Math.floor(totalInches / 12);
      const inc = Math.round(totalInches % 12);
      setFeet(ft);
      setInches(inc);
    }
  }, []);

  const handleCmChange = (val: number) => {
    setCmValue(val);
    const totalIn = val / 2.54;
    setFeet(Math.floor(totalIn / 12));
    setInches(Math.round(totalIn % 12));
  };

  const handleImperialChange = (ft: number, inc: number) => {
    setFeet(ft);
    setInches(inc);
    const totalIn = ft * 12 + inc;
    const computedCm = Math.round(totalIn * 2.54);
    setCmValue(computedCm);
  };

  const commonHeightsCm = [160, 165, 170, 175, 180, 185];
  const commonHeightsFt = [
    { ft: 5, in: 4, label: "5'4\"" },
    { ft: 5, in: 6, label: "5'6\"" },
    { ft: 5, in: 8, label: "5'8\"" },
    { ft: 5, in: 10, label: "5'10\"" },
    { ft: 6, in: 0, label: "6'0\"" },
    { ft: 6, in: 2, label: "6'2\"" },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cmValue >= 90 && cmValue <= 250) {
      onHeightConfirmed(cmValue);
    }
  };

  return (
    <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden p-6 sm:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
          <Ruler className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Step 1: Input Height
          </h2>
          <p className="text-sm text-slate-400">
            Ground-truth height calibrates pixel-to-metric scaling for the 38 dimensions.
          </p>
        </div>
      </div>

      <div className="flex bg-slate-800/80 p-1 rounded-xl mb-6 border border-slate-700/50">
        <button
          type="button"
          onClick={() => setUnit('cm')}
          className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${
            unit === 'cm'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Centimeters (cm)
        </button>
        <button
          type="button"
          onClick={() => setUnit('ft_in')}
          className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${
            unit === 'ft_in'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Feet & Inches (ft / in)
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {unit === 'cm' ? (
          <div>
            <label className="block text-xs font-semibold tracking-wider text-slate-400 uppercase mb-2">
              Standing Height (without shoes)
            </label>
            <div className="relative">
              <input
                type="number"
                min={100}
                max={250}
                value={cmValue}
                onChange={(e) => handleCmChange(Number(e.target.value))}
                className="w-full text-4xl sm:text-5xl font-mono font-bold bg-slate-950 border border-slate-700 rounded-xl px-5 py-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
              <span className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-lg">
                cm
              </span>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
              <span>{Math.floor(cmValue / 2.54 / 12)} ft {Math.round((cmValue / 2.54) % 12)} in</span>
              <span>Range: 100 - 250 cm</span>
            </div>

            {/* Quick Presets */}
            <div className="mt-4">
              <span className="text-xs text-slate-400 block mb-2 font-medium">Quick Select:</span>
              <div className="grid grid-cols-6 gap-2">
                {commonHeightsCm.map((h) => (
                  <button
                    key={h}
                    type="button"
                    onClick={() => handleCmChange(h)}
                    className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                      cmValue === h
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {h} cm
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div>
            <label className="block text-xs font-semibold tracking-wider text-slate-400 uppercase mb-2">
              Standing Height (without shoes)
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <input
                  type="number"
                  min={3}
                  max={8}
                  value={feet}
                  onChange={(e) => handleImperialChange(Number(e.target.value), inches)}
                  className="w-full text-4xl sm:text-5xl font-mono font-bold bg-slate-950 border border-slate-700 rounded-xl px-5 py-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                />
                <span className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-lg">
                  ft
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min={0}
                  max={11}
                  value={inches}
                  onChange={(e) => handleImperialChange(feet, Number(e.target.value))}
                  className="w-full text-4xl sm:text-5xl font-mono font-bold bg-slate-950 border border-slate-700 rounded-xl px-5 py-4 text-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                />
                <span className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-lg">
                  in
                </span>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
              <span>Approx. {cmValue} cm</span>
              <span>Range: 3&apos;4&quot; - 8&apos;2&quot;</span>
            </div>

            {/* Quick Presets */}
            <div className="mt-4">
              <span className="text-xs text-slate-400 block mb-2 font-medium">Quick Select:</span>
              <div className="grid grid-cols-6 gap-2">
                {commonHeightsFt.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => handleImperialChange(item.ft, item.in)}
                    className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                      feet === item.ft && inches === item.in
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 leading-relaxed">
            <span className="font-semibold text-white">Why height matters:</span> Accurate standing height establishes a millimeters-per-pixel ratio. Next, use your camera to capture a full-body stance to extract all 38 necessary clothing dimensions.
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 text-base transition-all active:scale-[0.99] cursor-pointer"
        >
          <span>Continue to Camera</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};
