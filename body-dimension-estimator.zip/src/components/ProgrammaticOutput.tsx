import React, { useState } from 'react';
import { Copy, Download, Check, FileJson, FileSpreadsheet, FileText, Table } from 'lucide-react';
import { BodyMeasurement } from '../types/measurements.ts';

interface ProgrammaticOutputProps {
  measurements: BodyMeasurement[];
  heightCm: number;
  heightIn: number;
  onUpdateValue?: (id: string, newCm: number) => void;
}

type ExportFormat = 'json' | 'csv' | 'tsv' | 'keyvalue' | 'table';

export const ProgrammaticOutput: React.FC<ProgrammaticOutputProps> = ({
  measurements,
  heightCm,
  heightIn,
  onUpdateValue,
}) => {
  const [format, setFormat] = useState<ExportFormat>('json');
  const [unit, setUnit] = useState<'cm' | 'in'>('cm');
  const [copied, setCopied] = useState<boolean>(false);

  // Generate output strings based on selected unit and format
  const getJsonString = (): string => {
    const dimensionsMap: Record<string, number> = {};
    measurements.forEach((m) => {
      dimensionsMap[m.name] = unit === 'cm' ? m.valueCm : m.valueIn;
    });

    const outputObj = {
      calibrated_height: {
        value: unit === 'cm' ? heightCm : heightIn,
        unit: unit,
        cm: heightCm,
        in: heightIn,
      },
      unit: unit,
      total_dimensions: measurements.length,
      dimensions: dimensionsMap,
    };

    return JSON.stringify(outputObj, null, 2);
  };

  const getCsvString = (): string => {
    const lines = ['Dimension,Value,Unit'];
    measurements.forEach((m) => {
      const val = unit === 'cm' ? m.valueCm : m.valueIn;
      lines.push(`"${m.name}",${val},${unit}`);
    });
    return lines.join('\n');
  };

  const getTsvString = (): string => {
    const lines = ['Dimension\tValue\tUnit'];
    measurements.forEach((m) => {
      const val = unit === 'cm' ? m.valueCm : m.valueIn;
      lines.push(`${m.name}\t${val}\t${unit}`);
    });
    return lines.join('\n');
  };

  const getKeyValueString = (): string => {
    return measurements
      .map((m) => {
        const val = unit === 'cm' ? m.valueCm : m.valueIn;
        return `${m.name}: ${val} ${unit}`;
      })
      .join('\n');
  };

  const getCurrentText = (): string => {
    switch (format) {
      case 'json':
        return getJsonString();
      case 'csv':
        return getCsvString();
      case 'tsv':
        return getTsvString();
      case 'keyvalue':
        return getKeyValueString();
      default:
        return getJsonString();
    }
  };

  const handleCopy = () => {
    const text = getCurrentText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    let content = '';
    let filename = `clothing_dimensions_${heightCm}cm`;
    let mimeType = 'text/plain';

    if (format === 'json') {
      content = getJsonString();
      filename += '.json';
      mimeType = 'application/json';
    } else if (format === 'csv') {
      content = getCsvString();
      filename += '.csv';
      mimeType = 'text/csv';
    } else if (format === 'tsv') {
      content = getTsvString();
      filename += '.tsv';
      mimeType = 'text/tab-separated-values';
    } else {
      content = getKeyValueString();
      filename += '.txt';
      mimeType = 'text/plain';
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl flex flex-col h-full overflow-hidden shadow-lg">
      {/* Top Controls Toolbar */}
      <div className="p-3 sm:p-4 border-b border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-3">
        {/* Format Selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            type="button"
            onClick={() => setFormat('json')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
              format === 'json'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileJson className="w-3.5 h-3.5" />
            <span>JSON</span>
          </button>
          <button
            type="button"
            onClick={() => setFormat('csv')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
              format === 'csv'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>
          <button
            type="button"
            onClick={() => setFormat('tsv')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
              format === 'tsv'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Tab-separated: 1-click paste directly into Excel or Google Sheets"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>TSV (Excel)</span>
          </button>
          <button
            type="button"
            onClick={() => setFormat('keyvalue')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
              format === 'keyvalue'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Text</span>
          </button>
          <button
            type="button"
            onClick={() => setFormat('table')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all ${
              format === 'table'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>Table</span>
          </button>
        </div>

        {/* Unit and Export Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Unit Toggle */}
          <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setUnit('cm')}
              className={`px-2 py-1 rounded font-bold ${
                unit === 'cm'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              cm
            </button>
            <button
              type="button"
              onClick={() => setUnit('in')}
              className={`px-2 py-1 rounded font-bold ${
                unit === 'in'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              in
            </button>
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Data'}</span>
          </button>

          {format !== 'table' && (
            <button
              type="button"
              onClick={handleDownload}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Content View */}
      <div className="flex-1 p-3 sm:p-4 overflow-auto bg-slate-950 font-mono text-xs">
        {format === 'table' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-3 font-semibold">#</th>
                  <th className="py-2 px-3 font-semibold">Dimension</th>
                  <th className="py-2 px-3 font-semibold text-right">Value ({unit})</th>
                  <th className="py-2 px-3 font-semibold text-right">
                    Alt ({unit === 'cm' ? 'in' : 'cm'})
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {measurements.map((m, idx) => {
                  const val = unit === 'cm' ? m.valueCm : m.valueIn;
                  const altVal = unit === 'cm' ? m.valueIn : m.valueCm;
                  return (
                    <tr key={m.id} className="hover:bg-slate-900/50 transition-colors">
                      <td className="py-1.5 px-3 text-slate-500">{idx + 1}</td>
                      <td className="py-1.5 px-3 text-white font-medium">{m.name}</td>
                      <td className="py-1.5 px-3 text-right text-amber-300 font-bold">
                        {val}
                      </td>
                      <td className="py-1.5 px-3 text-right text-slate-400">
                        {altVal}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <pre className="text-slate-200 whitespace-pre leading-relaxed select-all">
            {getCurrentText()}
          </pre>
        )}
      </div>

      {/* Output Stats Bar */}
      <div className="px-4 py-2 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span>{measurements.length} Dimensions ready for software export</span>
        <span>Calibrated at {heightCm} cm ({heightIn} in)</span>
      </div>
    </div>
  );
};
