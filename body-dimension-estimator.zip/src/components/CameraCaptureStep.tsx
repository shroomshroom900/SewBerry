import React, { useRef, useState, useEffect } from 'react';
import {
  Camera,
  RotateCcw,
  FlipHorizontal,
  Clock,
  Upload,
  AlertCircle,
  Check,
  ChevronLeft,
  Sparkles,
} from 'lucide-react';

interface CameraCaptureStepProps {
  heightCm: number;
  onBackToHeight: () => void;
  onPhotoConfirmed: (base64Data: string) => void;
  isProcessing: boolean;
}

export const CameraCaptureStep: React.FC<CameraCaptureStepProps> = ({
  heightCm,
  onBackToHeight,
  onPhotoConfirmed,
  isProcessing,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  // Countdown timer
  const [timerSeconds, setTimerSeconds] = useState<number>(3); // default 3s
  const [isCountingDown, setIsCountingDown] = useState<boolean>(false);
  const [countdownRemaining, setCountdownRemaining] = useState<number>(0);

  // Guide overlay toggle
  const [showGuide, setShowGuide] = useState<boolean>(true);

  // Start camera
  const startCamera = async (mode: 'user' | 'environment') => {
    try {
      setCameraError(null);
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: mode,
          width: { ideal: 1920, min: 640 },
          height: { ideal: 1080, min: 480 },
        },
        audio: false,
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError(
        'Unable to access camera. Please allow camera permissions, or upload a full-body photo below.'
      );
    }
  };

  useEffect(() => {
    startCamera(facingMode);
    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [facingMode]);

  const toggleCamera = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  const handleCapture = () => {
    if (timerSeconds > 0) {
      setIsCountingDown(true);
      setCountdownRemaining(timerSeconds);

      const interval = setInterval(() => {
        setCountdownRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsCountingDown(false);
            takeSnapshot();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      takeSnapshot();
    }
  };

  const takeSnapshot = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Flip horizontally if front-facing user camera for natural mirror feel
    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedImage(dataUrl);
  };

  const handleRetake = () => {
    setCapturedImage(null);
    if (!stream) {
      startCamera(facingMode);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCapturedImage(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleConfirm = () => {
    if (capturedImage) {
      onPhotoConfirmed(capturedImage);
    }
  };

  const heightInches = Math.round(heightCm / 2.54);
  const heightFeet = Math.floor(heightInches / 12);
  const heightRemInches = heightInches % 12;

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {/* Top Bar Navigation & Height Pill */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
        <button
          type="button"
          onClick={onBackToHeight}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Edit Height</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Calibrated Height:</span>
          <span className="text-xs font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2.5 py-1 rounded-md">
            {heightCm} cm ({heightFeet}&apos;{heightRemInches}&quot;)
          </span>
        </div>
      </div>

      {/* Main Viewport Container */}
      <div className="relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl aspect-[3/4] sm:aspect-[4/3] flex items-center justify-center">
        {/* Hidden Canvas for capture rendering */}
        <canvas ref={canvasRef} className="hidden" />

        {capturedImage ? (
          /* Preview Mode */
          <div className="relative w-full h-full flex flex-col items-center justify-center bg-black">
            <img
              src={capturedImage}
              alt="Body capture preview"
              className="w-full h-full object-contain"
            />

            {/* Overlay Banner */}
            <div className="absolute top-4 left-4 right-4 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl px-4 py-2.5 flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2 text-xs text-white">
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold">Snapshot captured</span>
              </div>
              <span className="text-xs text-slate-400">
                Ready to determine 38 clothing dimensions
              </span>
            </div>

            {/* Processing State Indicator */}
            {isProcessing && (
              <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-30">
                <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4 animate-pulse">
                  <Sparkles className="w-8 h-8 animate-spin" style={{ animationDuration: '3s' }} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  Calculating 38 Clothing Dimensions...
                </h3>
                <p className="text-xs text-slate-400 max-w-sm">
                  Detecting anatomical landmarks (HPS, bust apex, natural waist, crotch depth, seat, inseam) calibrated against {heightCm} cm height.
                </p>
                <div className="mt-4 w-48 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-500 to-amber-300 w-full animate-[shimmer_1.5s_infinite]" />
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Live Camera Stream */
          <div className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden">
            {cameraError ? (
              <div className="p-6 text-center max-w-md">
                <AlertCircle className="w-12 h-12 text-amber-400 mx-auto mb-3" />
                <h4 className="text-base font-bold text-white mb-2">Camera Access</h4>
                <p className="text-xs text-slate-400 mb-6 leading-relaxed">{cameraError}</p>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 mx-auto cursor-pointer shadow-lg shadow-amber-500/20"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload Full-Body Photo</span>
                </button>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                />

                {/* Silhouette Guidelines Overlay */}
                {showGuide && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-between py-6 px-4">
                    {/* Head level guide */}
                    <div className="w-40 sm:w-48 border-b-2 border-dashed border-amber-400/70 text-[10px] text-amber-300 font-mono text-center pb-1">
                      ▲ TOP OF HEAD (VERTEX)
                    </div>

                    {/* Shoulder & Torso Frame */}
                    <div className="w-64 sm:w-72 h-1/2 border-2 border-dashed border-cyan-400/40 rounded-3xl relative flex flex-col justify-between py-3 px-2">
                      <div className="w-full border-b border-cyan-400/40 text-[9px] text-cyan-300 font-mono text-center">
                        SHOULDERS & CHEST
                      </div>
                      <div className="w-full border-b border-amber-400/50 text-[9px] text-amber-300 font-mono text-center">
                        NATURAL WAIST
                      </div>
                      <div className="w-full text-[9px] text-cyan-300 font-mono text-center">
                        HIPS & SEAT
                      </div>
                    </div>

                    {/* Feet ground level guide */}
                    <div className="w-48 sm:w-56 border-t-2 border-dashed border-amber-400/70 text-[10px] text-amber-300 font-mono text-center pt-1">
                      ▼ FEET & FLOOR LEVEL
                    </div>
                  </div>
                )}

                {/* Countdown display */}
                {isCountingDown && (
                  <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-20">
                    <div className="w-28 h-28 rounded-full bg-amber-500 text-slate-950 font-black text-6xl flex items-center justify-center shadow-2xl animate-ping" style={{ animationDuration: '1s' }}>
                      {countdownRemaining}
                    </div>
                  </div>
                )}

                {/* Top controls inside camera view */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
                  <button
                    type="button"
                    onClick={() => setShowGuide((prev) => !prev)}
                    className={`text-xs px-3 py-1.5 rounded-lg backdrop-blur-md border font-medium transition-all ${
                      showGuide
                        ? 'bg-slate-900/80 text-amber-300 border-amber-500/30'
                        : 'bg-slate-900/50 text-slate-400 border-slate-700'
                    }`}
                  >
                    {showGuide ? 'Body Guide: ON' : 'Body Guide: OFF'}
                  </button>

                  <div className="flex items-center gap-2">
                    {/* Timer selector */}
                    <div className="flex items-center bg-slate-900/80 backdrop-blur-md border border-slate-700 rounded-lg p-0.5 text-xs">
                      <Clock className="w-3.5 h-3.5 text-slate-400 ml-2 mr-1" />
                      {[0, 3, 5, 10].map((sec) => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => setTimerSeconds(sec)}
                          className={`px-2 py-1 rounded-md text-[11px] font-semibold transition-all ${
                            timerSeconds === sec
                              ? 'bg-amber-500 text-slate-950'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {sec === 0 ? 'Off' : `${sec}s`}
                        </button>
                      ))}
                    </div>

                    {/* Camera switch */}
                    <button
                      type="button"
                      onClick={toggleCamera}
                      title="Flip camera"
                      className="p-2 bg-slate-900/80 backdrop-blur-md border border-slate-700 hover:border-slate-500 text-slate-300 hover:text-white rounded-lg transition-all"
                    >
                      <FlipHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Instructions pill */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/85 backdrop-blur-md border border-slate-700 text-slate-300 text-[11px] px-3.5 py-1.5 rounded-full shadow-lg pointer-events-none whitespace-nowrap">
                  Stand back 2–3 meters so your full body (head to feet) is visible
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Bottom Action Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        {capturedImage ? (
          <>
            <button
              type="button"
              onClick={handleRetake}
              disabled={isProcessing}
              className="w-full sm:w-auto px-5 py-3 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retake Photo</span>
            </button>

            <button
              type="button"
              onClick={handleConfirm}
              disabled={isProcessing}
              className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>Calculate 38 Clothing Dimensions</span>
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full sm:w-auto px-4 py-2.5 text-xs text-slate-400 hover:text-white border border-slate-800 hover:border-slate-700 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Upload Photo Instead</span>
            </button>

            <button
              type="button"
              onClick={handleCapture}
              disabled={isCountingDown}
              className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Camera className="w-5 h-5" />
              <span>
                {timerSeconds > 0
                  ? `Capture with ${timerSeconds}s Timer`
                  : 'Capture Photo Now'}
              </span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};
