import React, { useState, useMemo } from 'react';
import {
  Copy,
  Download,
  Printer,
  RotateCcw,
  Search,
  Check,
  Edit2,
  X,
  Filter,
} from 'lucide-react';
import { BodyMeasurement } from '../types/measurements.ts';

interface DimensionsResultStepProps {
  measurements: BodyMeasurement[];
  heightCm: number;
  heightIn: number;
  detectionNotes?: string;
  onRetake: () => void;
  onUpdateMeasurement: (id: string, newCm: number) => void;
}

export const DimensionsResultStep: React.FC<DimensionsResultStepProps> = ({
  measurements,
  heightCm,
  heightIn,
  detectionNotes,
  onRetake,
  onUpdateMeasurement,
}) => {
  const [displayUnit, setDisplayUnit] = useState<'in' | 'cm'>('in');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copied, setCopied] = useState<boolean>(false);

  // Quick edit state
  const [editingItem, setEditingItem] = useState<BodyMeasurement | null>(null);
  const [editValue, setEditValue] = useState<string>('');

  const categories = useMemo(() => {
    const set = new Set<string>();
    measurements.forEach((m) => set.add(m.category));
    return ['All', ...Array.from(set)];
  }, [measurements]);

  const filteredMeasurements = useMemo(() => {
    return measurements.filter((m) => {
      const matchesSearch =
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.landmark.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory =
        selectedCategory === 'All' || m.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [measurements, searchQuery, selectedCategory]);

  const handleCopyAll = () => {
    const header = `CLOTHING BODY DIMENSIONS (Calibrated Height: ${heightCm} cm / ${heightIn} in)\nTotal Dimensions: ${measurements.length}\n${'='.repeat(60)}\n\n`;
    const rows = measurements
      .map(
        (m, i) =>
          `${(i + 1).toString().padStart(2, '0')}. ${m.name.padEnd(28)} : ${m.valueIn} in (${m.valueCm} cm) - [${m.landmark}]`
      )
      .join('\n');

    navigator.clipboard.writeText(header + rows);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadCSV = () => {
    const csvRows = [
      ['Dimension Name', 'Category', 'Value (Inches)', 'Value (Centimeters)', 'Landmark Definition'],
      ...measurements.map((m) => [
        `"${m.name}"`,
        `"${m.category}"`,
        m.valueIn.toFixed(1),
        m.valueCm.toFixed(1),
        `"${m.landmark}"`,
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `clothing_dimensions_${heightCm}cm.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const openEdit = (item: BodyMeasurement) => {
    setEditingItem(item);
    setEditValue(displayUnit === 'in' ? item.valueIn.toString() : item.valueCm.toString());
  };

  const saveEdit = () => {
    if (!editingItem) return;
    const num = parseFloat(editValue);
    if (!isNaN(num) && num > 0) {
      const newCm = displayUnit === 'in' ? num * 2.54 : num;
      onUpdateMeasurement(editingItem.id, Number(newCm.toFixed(1)));
    }
    setEditingItem(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Summary & Actions Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Measurement Complete
              </span>
              <span className="text-xs text-slate-400">
                {measurements.length} / 38 Necessary Dimensions
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Clothing Dimensions Spec Sheet
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Calibrated with your standing height of{' '}
              <strong className="text-amber-400 font-semibold">{heightCm} cm</strong> ({heightIn} in).
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Unit Toggle */}
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-700/80">
              <button
                type="button"
                onClick={() => setDisplayUnit('in')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  displayUnit === 'in'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Inches (in)
              </button>
              <button
                type="button"
                onClick={() => setDisplayUnit('cm')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  displayUnit === 'cm'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Centimeters (cm)
              </button>
            </div>

            <button
              type="button"
              onClick={handleCopyAll}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied 38 Dimensions!' : 'Copy All'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadCSV}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              type="button"
              onClick={onRetake}
              className="px-3.5 py-2 bg-slate-800/80 hover:bg-slate-700 text-amber-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-amber-500/30 transition-all cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Scan</span>
            </button>
          </div>
        </div>

        {/* Search & Category Filter Toolbar */}
        <div className="mt-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by dimension name (e.g., waist, bust, crotch, inseam)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500 shrink-0 ml-1 mr-1" />
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all ${
                  selectedCategory === cat
                    ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {detectionNotes && (
          <div className="mt-3 text-[11px] text-slate-400 bg-slate-950/40 border border-slate-800/80 rounded-lg px-3 py-1.5">
            <span className="text-slate-300 font-medium">Vision Calibration:</span> {detectionNotes}
          </div>
        )}
      </div>

      {/* Grid of Measurements */}
      {filteredMeasurements.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
          <p className="text-slate-400 text-sm">No dimensions matched &ldquo;{searchQuery}&rdquo;</p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
            }}
            className="mt-3 text-xs text-amber-400 hover:underline"
          >
            Clear search filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
          {filteredMeasurements.map((m) => {
            const primaryValue = displayUnit === 'in' ? `${m.valueIn} in` : `${m.valueCm} cm`;
            const secondaryValue = displayUnit === 'in' ? `${m.valueCm} cm` : `${m.valueIn} in`;

            return (
              <div
                key={m.id}
                className="group relative bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-xl p-4 transition-all shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400/80 bg-amber-500/10 px-2 py-0.5 rounded">
                      {m.category}
                    </span>
                    <button
                      type="button"
                      onClick={() => openEdit(m)}
                      title="Adjust value"
                      className="opacity-40 group-hover:opacity-100 text-slate-400 hover:text-amber-400 transition-opacity p-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug mb-1">
                    {m.name}
                  </h3>

                  <p className="text-[11px] text-slate-400 leading-relaxed mb-3 line-clamp-2" title={m.landmark}>
                    {m.landmark}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-baseline justify-between">
                  <div>
                    <span className="text-2xl font-black font-mono tracking-tight text-white">
                      {primaryValue}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-slate-500 bg-slate-950/60 px-2 py-0.5 rounded border border-slate-800">
                    {secondaryValue}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Manual Fine-Tune Modal */}
      {editingItem && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-base font-bold text-white">
                Adjust {editingItem.name}
              </h4>
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">{editingItem.landmark}</p>

            <div className="mb-6">
              <label className="block text-xs font-semibold text-slate-300 uppercase mb-2">
                Value ({displayUnit === 'in' ? 'Inches' : 'Centimeters'})
              </label>
              <div className="relative">
                <input
                  type="number"
                  step={0.1}
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className="w-full text-2xl font-mono font-bold bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  autoFocus
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-sm">
                  {displayUnit}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={saveEdit}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
